package io.github.romanvht.byedpi.utility

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.activities.MainActivity
import io.github.romanvht.byedpi.data.PAUSE_ACTION
import io.github.romanvht.byedpi.data.RESUME_ACTION
import io.github.romanvht.byedpi.data.STOP_ACTION
import io.github.romanvht.byedpi.receiver.NotificationActionReceiver
import io.github.romanvht.byedpi.widgets.WidgetStateManager

fun registerNotificationChannel(context: Context, id: String, @StringRes name: Int) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val channel = NotificationChannel(
            id,
            context.getString(name),
            NotificationManager.IMPORTANCE_DEFAULT
        )
        channel.enableLights(false)
        channel.enableVibration(false)
        channel.setShowBadge(false)

        manager.createNotificationChannel(channel)
    }
}

fun createConnectionNotification(
    context: Context,
    channelId: String,
    @StringRes title: Int,
    @StringRes content: Int,
    statusLine: String? = null,
    service: Class<*>,
): Notification {
    val baseText = context.getString(content)
    val isTgRunning = WidgetStateManager.isTgProxyRunning(context)

    val titleText = if (isTgRunning) {
        context.getString(R.string.notification_both_active)
    } else {
        context.getString(title)
    }

    val statusSummary = if (isTgRunning) {
        if (!statusLine.isNullOrBlank()) "$baseText • $statusLine" else "$baseText • TG Proxy: ON"
    } else {
        baseText
    }

    val bigText = if (!statusLine.isNullOrBlank() && !isTgRunning) {
        "$baseText\n$statusLine"
    } else {
        statusSummary
    }

    val tgActionIntent = Intent(context, NotificationActionReceiver::class.java).apply {
        action = NotificationActionReceiver.ACTION_TOGGLE_TG_PROXY
    }
    val tgPendingIntent = PendingIntent.getBroadcast(
        context,
        101,
        tgActionIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val tgActionLabel = if (isTgRunning) "TG Proxy: Выкл" else "TG Proxy: Вкл"

    return NotificationCompat.Builder(context, channelId)
        .setSmallIcon(R.drawable.ic_notification)
        .setSilent(true)
        .setContentTitle(titleText)
        .setContentText(statusSummary)
        .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
        .addAction(0, context.getString(R.string.service_pause_btn),
            PendingIntent.getService(
                context,
                0,
                Intent(context, service).setAction(PAUSE_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .addAction(0, context.getString(R.string.service_stop_btn),
            PendingIntent.getService(
                context,
                0,
                Intent(context, service).setAction(STOP_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .addAction(0, tgActionLabel, tgPendingIntent)
        .setContentIntent(
            PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .build()
}

fun createPauseNotification(
    context: Context,
    channelId: String,
    @StringRes title: Int,
    @StringRes content: Int,
    service: Class<*>,
): Notification =
    NotificationCompat.Builder(context, channelId)
        .setSmallIcon(R.drawable.ic_notification)
        .setSilent(true)
        .setContentTitle(context.getString(title))
        .setContentText(context.getString(content))
        .addAction(0, context.getString(R.string.service_start_btn),
            PendingIntent.getService(
                context,
                0,
                Intent(context, service).setAction(RESUME_ACTION),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .setContentIntent(
            PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE,
            )
        )
        .build()
