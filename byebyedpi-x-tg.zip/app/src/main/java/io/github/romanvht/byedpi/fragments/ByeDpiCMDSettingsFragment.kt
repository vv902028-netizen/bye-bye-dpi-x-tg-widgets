package io.github.romanvht.byedpi.fragments

import android.net.VpnService
import android.os.Bundle
import androidx.core.content.edit
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.preference.*
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.utility.findPreferenceNotNull
import androidx.appcompat.app.AlertDialog
import io.github.romanvht.byedpi.data.AppStatus
import io.github.romanvht.byedpi.data.Command
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.services.ServiceManager
import io.github.romanvht.byedpi.services.appStatus
import io.github.romanvht.byedpi.utility.ClipboardUtils
import io.github.romanvht.byedpi.utility.HistoryUtils
import io.github.romanvht.byedpi.utility.getPreferences
import io.github.romanvht.byedpi.utility.mode

class ByeDpiCMDSettingsFragment : PreferenceFragmentCompat() {

    private lateinit var cmdHistoryUtils: HistoryUtils
    private lateinit var editTextPreference: EditTextPreference
    private lateinit var historyHeader: Preference
    private val historyPreferences = mutableListOf<Preference>()

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.byedpi_cmd_settings, rootKey)

        cmdHistoryUtils = HistoryUtils(requireContext())

        editTextPreference = findPreferenceNotNull("byedpi_cmd_args")
        historyHeader = findPreferenceNotNull("cmd_history_header")

        editTextPreference.setOnPreferenceChangeListener { _, newValue ->
            val newCommand = io.github.romanvht.byedpi.utility.StrategyUtils.normalizeCommand(newValue.toString())
            val ctx = context ?: return@setOnPreferenceChangeListener true

            if (newCommand.isNotBlank()) {
                ctx.getPreferences().edit(commit = true) {
                    putString("byedpi_cmd_args", newCommand)
                    putBoolean("byedpi_enable_cmd_settings", true)
                }
                cmdHistoryUtils.addCommand(newCommand)
                val matching = io.github.romanvht.byedpi.utility.StrategyUtils.getStrategies(ctx).find { it.command.trim() == newCommand }
                if (matching != null) {
                    ctx.getPreferences().edit(commit = true) {
                        putString(io.github.romanvht.byedpi.utility.StrategyUtils.KEY_ACTIVE_STRATEGY_ID, matching.id)
                    }
                }
                restartService()
            }

            updateHistoryItems()
            true
        }

        historyHeader.setOnPreferenceClickListener {
            showHistoryClearDialog()
            true
        }

        updateHistoryItems()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.post {
            view.findViewById<View>(R.id.btn_clear)?.setOnClickListener {
                editTextPreference.text = ""
                updateHistoryItems()
            }

            view.findViewById<View>(R.id.btn_paste)?.setOnClickListener {
                val text = ClipboardUtils.paste(requireContext())
                if (!text.isNullOrBlank()) {
                    editTextPreference.text = text
                    cmdHistoryUtils.addCommand(text)
                    updateHistoryItems()
                }
            }

            view.findViewById<View>(R.id.btn_save_strategy)?.setOnClickListener {
                val currentText = editTextPreference.text?.trim()
                if (!currentText.isNullOrBlank()) {
                    showSaveAsStrategyDialog(currentText)
                } else {
                    Toast.makeText(requireContext(), R.string.strategy_command_empty, Toast.LENGTH_SHORT).show()
                }
            }

            view.findViewById<View>(R.id.btn_my_strategies)?.setOnClickListener {
                parentFragmentManager
                    .beginTransaction()
                    .replace(R.id.settings, StrategiesFragment())
                    .addToBackStack(null)
                    .commit()
            }
        }
    }

    private fun showSaveAsStrategyDialog(command: String, initialName: String? = null) {
        val context = requireContext()
        val input = EditText(context).apply {
            hint = getString(R.string.strategy_name_hint)
            if (!initialName.isNullOrBlank()) setText(initialName)
        }
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
            addView(input)
        }

        AlertDialog.Builder(context, R.style.CustomAlertDialog)
            .setTitle(R.string.strategy_save_to_my)
            .setView(container)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val created = io.github.romanvht.byedpi.utility.StrategyUtils.addStrategy(context, name, command)
                    io.github.romanvht.byedpi.utility.StrategyUtils.applyStrategy(context, created)
                    Toast.makeText(context, R.string.strategy_added, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, R.string.strategy_name_empty, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun updateHistoryItems() {
        if (listView !== null) {
            listView.itemAnimator = null
        }

        historyPreferences.forEach { preference ->
            preferenceScreen.removePreference(preference)
        }

        historyPreferences.clear()
        val history = cmdHistoryUtils.getHistory()
        historyHeader.isVisible = history.isNotEmpty()

        if (history.isNotEmpty()) {
            history.sortedWith(compareByDescending<Command> { it.pinned }.thenBy { history.indexOf(it) })
                .forEachIndexed { _, command ->
                    val preference = createPreference(command)
                    historyPreferences.add(preference)
                    preferenceScreen.addPreference(preference)
                }
        }
    }

    private fun createPreference(command: Command) =
        object : Preference(requireContext()) {
            override fun onBindViewHolder(holder: PreferenceViewHolder) {
                super.onBindViewHolder(holder)

                val nameView = holder.itemView.findViewById<TextView>(R.id.command_name)
                val summaryView = holder.itemView.findViewById<TextView>(android.R.id.summary)
                val pinIcon = holder.itemView.findViewById<ImageView>(R.id.pin_icon)
                val commandName = command.name

                if (!commandName.isNullOrBlank()) {
                    nameView.visibility = View.VISIBLE
                    nameView.text = command.name
                } else {
                    nameView.visibility = View.GONE
                }

                val summaryText = buildSummary(command)
                if (summaryText.isNotBlank()) {
                    summaryView.visibility = View.VISIBLE
                    summaryView.text = summaryText
                } else {
                    summaryView.visibility = View.GONE
                }

                pinIcon.visibility = if (command.pinned) View.VISIBLE else View.GONE
            }
        }.apply {
            title = command.text
            layoutResource = R.layout.history_item
            setOnPreferenceClickListener {
                showActionDialog(command)
                true
            }
        }

    private fun buildSummary(command: Command): String {
        val parts = mutableListOf<String>()

        if (command.text == editTextPreference.text) {
            parts.add(getString(R.string.cmd_history_applied))
        }

        return parts.joinToString(" • ")
    }

    private fun showHistoryClearDialog() {
        val options = arrayOf(
            getString(R.string.cmd_history_delete_unpinned),
            getString(R.string.cmd_history_delete_all),
        )

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.cmd_history_menu))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> deleteUnpinnedHistory()
                    1 -> deleteAllHistory()
                }
            }
            .setNegativeButton(getString(android.R.string.cancel), null)
            .show()
    }

    private fun deleteAllHistory() {
        cmdHistoryUtils.clearAllHistory()
        updateHistoryItems()
    }

    private fun deleteUnpinnedHistory() {
        cmdHistoryUtils.clearUnpinnedHistory()
        updateHistoryItems()
    }

    private fun showActionDialog(command: Command) {
        val options = arrayOf(
            getString(R.string.cmd_history_apply),
            getString(R.string.strategy_save_to_my),
            if (command.pinned) getString(R.string.cmd_history_unpin) else getString(R.string.cmd_history_pin),
            getString(R.string.cmd_history_rename),
            getString(R.string.cmd_history_edit),
            getString(R.string.cmd_history_copy),
            getString(R.string.cmd_history_delete)
        )

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.cmd_history_menu))
            .setItems(options) { _, which ->
                when (which) {
                    0 -> applyCommand(command.text)
                    1 -> showSaveAsStrategyDialog(command.text, command.name)
                    2 -> if (command.pinned) unpinCommand(command.text) else pinCommand(command.text)
                    3 -> showRenameDialog(command)
                    4 -> showEditDialog(command)
                    5 -> ClipboardUtils.copy(requireContext(), command.text, "command")
                    6 -> deleteCommand(command.text)
                }
            }
            .show()
    }

    private fun showRenameDialog(command: Command) {
        val input = EditText(requireContext()).apply {
            setText(command.name)
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
            addView(input)
        }

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.cmd_history_rename))
            .setView(container)
            .setPositiveButton(getString(android.R.string.ok)) { _, _ ->
                val newName = input.text.toString()
                if (newName != command.name) {
                    cmdHistoryUtils.renameCommand(command.text, newName)
                    updateHistoryItems()
                }
            }
            .setNegativeButton(getString(android.R.string.cancel), null)
            .show()
    }

    private fun showEditDialog(command: Command) {
        val input = EditText(requireContext()).apply {
            setText(command.text)
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 20, 50, 20)
            addView(input)
        }

        AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.cmd_history_edit))
            .setView(container)
            .setPositiveButton(getString(android.R.string.ok)) { _, _ ->
                val newText = input.text.toString()
                if (newText.isNotBlank() && newText != command.text) {
                    cmdHistoryUtils.editCommand(command.text, newText)
                    if (editTextPreference.text == command.text) applyCommand(newText)
                    updateHistoryItems()
                }
            }
            .setNegativeButton(getString(android.R.string.cancel), null)
            .show()
    }

    private fun applyCommand(command: String) {
        val ctx = context ?: return
        val clean = io.github.romanvht.byedpi.utility.StrategyUtils.normalizeCommand(command)
        editTextPreference.text = clean
        ctx.getPreferences().edit(commit = true) {
            putString("byedpi_cmd_args", clean)
            putBoolean("byedpi_enable_cmd_settings", true)
        }
        cmdHistoryUtils.addCommand(clean)
        val matching = io.github.romanvht.byedpi.utility.StrategyUtils.getStrategies(ctx).find { it.command.trim() == clean }
        if (matching != null) {
            io.github.romanvht.byedpi.utility.StrategyUtils.applyStrategy(ctx, matching)
        } else {
            restartService()
        }
        updateHistoryItems()
    }

    private fun pinCommand(command: String) {
        cmdHistoryUtils.pinCommand(command)
        updateHistoryItems()
    }

    private fun unpinCommand(command: String) {
        cmdHistoryUtils.unpinCommand(command)
        updateHistoryItems()
    }

    private fun deleteCommand(command: String) {
        cmdHistoryUtils.deleteCommand(command)
        updateHistoryItems()
    }

    private fun restartService() {
        if (appStatus.first == AppStatus.Running) {
            val ctx = context ?: return
            val mode = ctx.getPreferences().mode()
            if (mode == Mode.VPN && VpnService.prepare(ctx) != null) return

            ServiceManager.restart(ctx, mode)
            Toast.makeText(ctx, R.string.service_restart, Toast.LENGTH_SHORT).show()
        }
    }
}