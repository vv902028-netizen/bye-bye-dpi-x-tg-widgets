package io.github.romanvht.byedpi.activities

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.color.DynamicColors
import androidx.core.content.edit
import io.github.romanvht.byedpi.utility.SettingsUtils
import io.github.romanvht.byedpi.utility.getPreferences
import io.github.romanvht.byedpi.utility.getStringNotNull

abstract class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        val prefs = getPreferences()

        val lang = prefs.getStringNotNull("language", "system")
        SettingsUtils.setLang(lang)

        val theme = prefs.getStringNotNull("app_theme", "system")
        SettingsUtils.setTheme(theme)

        val accentColor = prefs.getStringNotNull("accent_color", "dynamic")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && accentColor == "dynamic") {
            DynamicColors.applyToActivityIfAvailable(this)
        } else {
            val themeRes = when (accentColor) {
                "ocean" -> io.github.romanvht.byedpi.R.style.Theme_ByeDPI_Ocean
                "emerald" -> io.github.romanvht.byedpi.R.style.Theme_ByeDPI_Emerald
                "sunset" -> io.github.romanvht.byedpi.R.style.Theme_ByeDPI_Sunset
                "violet" -> io.github.romanvht.byedpi.R.style.Theme_ByeDPI_Violet
                else -> io.github.romanvht.byedpi.R.style.Theme_ByeDPI_Indigo
            }
            setTheme(themeRes)
        }

        super.onCreate(savedInstanceState)
    }

}