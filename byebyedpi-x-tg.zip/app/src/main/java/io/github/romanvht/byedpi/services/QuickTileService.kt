package io.github.romanvht.byedpi.services

import android.content.ComponentName
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import androidx.annotation.RequiresApi
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.widgets.WidgetStateManager

@RequiresApi(Build.VERSION_CODES.N)
class QuickTileService : TileService() {

    companion object {
        private const val TAG = "QuickTileService"
        private var instance: QuickTileService? = null
        @Volatile private var lastClickMs = 0L
        private const val DEBOUNCE_MS = 600L

        fun updateTile() {
            instance?.updateStatus()
            TgProxyTileService.updateTile()
            CombinedTileService.updateTile()
        }

        fun requestListening(service: TileService) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    requestListeningState(service, ComponentName(service, QuickTileService::class.java))
                    requestListeningState(service, ComponentName(service, TgProxyTileService::class.java))
                    requestListeningState(service, ComponentName(service, CombinedTileService::class.java))
                } catch (e: Exception) {
                    Log.d(TAG, "requestListeningState error: ${e.message}")
                }
            }
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        instance = this
        updateStatus()
    }

    override fun onStopListening() {
        super.onStopListening()
        if (instance == this) {
            instance = null
        }
    }

    override fun onClick() {
        super.onClick()

        val now = System.currentTimeMillis()
        if (now - lastClickMs < DEBOUNCE_MS) {
            Log.d(TAG, "Tile click debounced")
            return
        }
        lastClickMs = now

        WidgetStateManager.toggleVpn(this)
        updateStatus()
        CombinedTileService.updateTile()
    }

    fun updateStatus() {
        val tile = qsTile ?: return
        val isRunning = WidgetStateManager.isVpnRunning()

        tile.state = if (isRunning) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = getString(R.string.tile_vpn_label)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = if (isRunning) getString(R.string.tile_status_active) else getString(R.string.tile_status_inactive)
        }

        try {
            tile.updateTile()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update tile", e)
        }
    }
}
