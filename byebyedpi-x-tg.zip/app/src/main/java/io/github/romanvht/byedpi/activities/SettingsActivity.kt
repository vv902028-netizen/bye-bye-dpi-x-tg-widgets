package io.github.romanvht.byedpi.activities

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import io.github.romanvht.byedpi.R
import io.github.romanvht.byedpi.fragments.ByeDpiCMDSettingsFragment
import io.github.romanvht.byedpi.fragments.ByeDpiUISettingsFragment
import io.github.romanvht.byedpi.fragments.MainSettingsFragment
import io.github.romanvht.byedpi.utility.SettingsUtils
import io.github.romanvht.byedpi.utility.getPreferences
import androidx.core.content.edit

class SettingsActivity : BaseActivity(), PreferenceFragmentCompat.OnPreferenceStartFragmentCallback {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val openFragment = intent.getStringExtra("open_fragment")

        val targetFragment = when (openFragment) {
            "cmd" -> ByeDpiCMDSettingsFragment()
            "ui" -> ByeDpiUISettingsFragment()
            "strategies" -> io.github.romanvht.byedpi.fragments.StrategiesFragment()
            else -> MainSettingsFragment()
        }

        supportFragmentManager
            .beginTransaction()
            .setCustomAnimations(
                R.anim.m3_shared_axis_x_enter,
                R.anim.m3_shared_axis_x_exit,
                R.anim.m3_shared_axis_x_pop_enter,
                R.anim.m3_shared_axis_x_pop_exit
            )
            .replace(R.id.settings, targetFragment)
            .commit()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                } else {
                    finish()
                    overridePendingTransition(R.anim.m3_shared_axis_x_pop_enter, R.anim.m3_shared_axis_x_pop_exit)
                }
            }
        })
    }

    override fun onPreferenceStartFragment(
        caller: PreferenceFragmentCompat,
        pref: Preference
    ): Boolean {
        val fragmentClassName = pref.fragment ?: return false
        val fragment = supportFragmentManager.fragmentFactory.instantiate(
            classLoader,
            fragmentClassName
        )
        fragment.arguments = pref.extras
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                R.anim.m3_shared_axis_x_enter,
                R.anim.m3_shared_axis_x_exit,
                R.anim.m3_shared_axis_x_pop_enter,
                R.anim.m3_shared_axis_x_pop_exit
            )
            .replace(R.id.settings, fragment)
            .addToBackStack(null)
            .commit()
        return true
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_settings, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        android.R.id.home -> {
            onBackPressedDispatcher.onBackPressed()
            true
        }

        R.id.action_reset_settings -> {
            val prefs = getPreferences()
            prefs.edit { clear() }
            recreate()
            true
        }

        R.id.action_export_settings -> {
            val fileName = "bbd_${System.currentTimeMillis().toReadableDateTime()}.json"
            exportSettingsLauncher.launch(fileName)
            true
        }

        R.id.action_import_settings -> {
            importSettingsLauncher.launch(arrayOf("application/json"))
            true
        }

        else -> super.onOptionsItemSelected(item)
    }

    private val exportSettingsLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            SettingsUtils.exportSettings(this, it)
        }
    }

    private val importSettingsLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            SettingsUtils.importSettings(this, it) {
                recreate()
            }
        }
    }

    private fun Long.toReadableDateTime(): String {
        val format = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.getDefault())
        return format.format(this)
    }
}